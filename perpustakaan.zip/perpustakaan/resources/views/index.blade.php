@extends('layout.main')

@section('title', 'Perpustakaaan')

@section('container')
    <div class="container">
        <div class="row">
            <div class="col-10">
            <h1 class="mt-3">Hi, Selamat Datang :)</h1>
            </div>
        </div>
    </div>
@endsection