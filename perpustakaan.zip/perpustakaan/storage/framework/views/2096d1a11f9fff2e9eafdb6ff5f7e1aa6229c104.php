<?php $__env->startSection('title', 'Daftar Buku'); ?>


<?php $__env->startSection('container'); ?>

<div class="container">
    <div class="row">
        <div class="col-10">
            <h1 class="mt-3">Daftar Buku</h1>

            <a href="/buku/create" class="btn btn-primary my-3">Tambah Data Buku</a>
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Penerbit</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($mhs->nama); ?></td>
                        <td><?php echo e($mhs->penerbit); ?></td>
                        <td>
                            <a href="/buku/edit/<?php echo e($mhs->id); ?>" >Edit</a>

                            <a href="/buku/delete/<?php echo e($mhs->id); ?>" >Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
   <?php echo e($mahasiswa->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan\resources\views/buku/index.blade.php ENDPATH**/ ?>